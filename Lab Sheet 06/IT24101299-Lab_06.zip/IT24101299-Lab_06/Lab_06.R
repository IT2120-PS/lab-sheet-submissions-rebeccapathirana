getwd()
setwd("C:/Users/Rebecca/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24101299-Lab_06")
getwd()

#Q1
#Binomal distribution
pbinom(46, 50, 0.85,lower.tail = FALSE)

#Q2
#Number of calls received in given day
#poisson distribution
dpois(15, 12)
